import { AppRegistry } from 'react-native';
import Demo from './app';

AppRegistry.registerComponent('demo', () => Demo);
